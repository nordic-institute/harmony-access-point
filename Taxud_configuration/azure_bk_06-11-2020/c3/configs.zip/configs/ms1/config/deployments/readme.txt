This directory is the staging area for applications whose staging mode is "staged".
Users and administrators should not directly manipulate applications in this subhierarchy!  
Only the WebLogic deployment software should ever access these files.