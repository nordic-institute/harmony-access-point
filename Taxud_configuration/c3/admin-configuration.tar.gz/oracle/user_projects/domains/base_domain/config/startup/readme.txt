This directory contains system modules that contain startup plans. Startup plans are used to generate 
shell scripts that can be used as part of server startup. 